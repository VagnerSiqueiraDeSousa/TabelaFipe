package br.com.vagner.TabelaFipe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TabelaFipeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TabelaFipeApplication.class, args);
	}

}
